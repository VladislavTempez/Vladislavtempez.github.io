#load "graphics.cma";;



let move_disc initial final towers = (*Move a disc from initial tower to final tower. towers is an array that represents the configration of the 3 towers : each case contains a list of the discs currently on this tower.*)
 
  towers.(final)<-((List.hd(towers.(initial)))::towers.(final)); (*The top disc of tower inital is taken and put ontop of tower final*)
  towers.(initial)<-(List.tl(towers.(initial))); (*The top disc of tower initial is deleted from tower initial*)
   ();;

let rec hanoi_rec n initial final middle towers = (*solve the hanoi towers problem with n discs stacked on initial towers and puts these on final tower*)
  if n=0 then ()
  else 
    begin
      hanoi_rec (n-1) initial middle final towers; (*puts the n-1 firsts discs on the middle tower*)
      move_disc initial final towers; (*moves le last  and larger disc from th initial tower to the final tower*)
      hanoi_rec (n-1) middle final initial towers; (*moves les n-1 smaller discs from the middle tower to the final tower*)
    end;
;;

let rec make_list =function (*make a list of the n first integers in descending order*)
  |0->[]
  |n->n::make_list (n-1)
;;


let hanoi_towers n= (*solve the hanoi tower problem with n discs on the first tower*)
  let initial_tower_content =List.rev (make_list n) in
  hanoi_rec n 0 2 1 [|initial_tower_content;[];[]|]
;;

let rec hanoi_multi disc_number initial final free towers = 
  if disc_number=0 then ()
  else 
  let k=(List.length free) in
  if (disc_number<=k+1) then (*The discs are scattered on the free towers, one disc per tower.*)
    begin
      let first_free_list=ref [] and free_temp=ref free in
      for j=0 to (disc_number-2) do
	first_free_list:=(List.hd !free_temp)::(!first_free_list);
	free_temp:=(List.tl !free_temp);
	move_disc initial (List.hd !first_free_list) towers;
      done;

      move_disc initial final towers;
      for j=0 to disc_number-2 do (* the scattered discs are moved toward the final tower in the right order*)

	move_disc (List.hd !first_free_list) final towers;
	first_free_list :=(List.tl !first_free_list);
      done;
    end
  else
    if k=1 then (hanoi_rec disc_number initial final (List.hd free) towers)
    else
      let first_free=(List.hd free) in


      (hanoi_multi (disc_number/2) initial first_free (List.tl free) towers; (*puts the n/2 firsts discs on the first free tower*)
       hanoi_multi (disc_number-disc_number/2) initial final (List.tl free) towers; (*moves the remnants discs from the initial tower to the final tower*) 
       hanoi_multi (disc_number/2) first_free final (initial::List.tl free) towers;) (*moves the remnants discs from the last first_free tower to the final tower*)
;;

let hanoi_multi_towers n k= (*solve the hanoi tower problem with n discs on the first tower and k towers*)
  let initial_tower_content =List.rev (make_list n) and free_towers = (List.tl (make_list (k-1))) in
  let towers=Array.make k [] in
  towers.(0)<-initial_tower_content;
  hanoi_multi n 0 (k-1) free_towers towers
;;

let rec hanoi_rec_move_number n initial final middle towers = (*solve the hanoi towers problem with n discs stacked on initial towers and puts these on final tower*)
  if n=0 then 0
  else 
    begin
      let res=hanoi_rec_move_number (n-1) initial middle final towers in (*puts the n-1 firsts discs on the middle tower*)
      move_disc initial final towers; (*moves le last  and larger disc from th initial tower to the final tower*)
      res+1+hanoi_rec_move_number (n-1) middle final initial towers; (*moves les n-1 smaller discs from the middle tower to the final tower*)
    end;
;;

let rec hanoi_multi_move_number disc_number initial final free towers = 
  if disc_number=0 then 0
  else 
    let k=(List.length free) in
    if disc_number<=(k+1) then (*The discs are scattered on the free towers, one disc per tower.*)
      begin
	  let first_free_list=ref [] and free_temp=ref free in
	  for j=0 to (disc_number-2) do
	    first_free_list:=(List.hd !free_temp)::(!first_free_list);
	    free_temp:=(List.tl !free_temp);
	    move_disc initial (List.hd !first_free_list) towers;
	  done;
	  move_disc initial final towers;
	  for j=0 to disc_number-2 do (* the scattered discs are moved toward the final tower in the right order*)
	    move_disc (List.hd !first_free_list) final towers;
	    first_free_list :=(List.tl !first_free_list);
	  done;
	  2*disc_number-1;
      end
      else
      if k=1 then (hanoi_rec_move_number disc_number initial final (List.hd free) towers)
      else
	
	let first_free=(List.hd free) and res=ref 0 in
	res := !res+(hanoi_multi_move_number (disc_number/2) initial first_free (List.tl free) towers); (*puts the n/2 firsts discs on the first free tower*)
	res:=!res+(hanoi_multi_move_number (disc_number-disc_number/2) initial final (List.tl free) towers); (*moves the remnants discs from the initial tower to the final tower*) 
	res:=!res+(hanoi_multi_move_number (disc_number/2) first_free final (initial::List.tl free) towers); (*moves the remnants discs from the last first_free tower to the final tower*)
	    !res;
;;

let hanoi_multi_towers_number n k= (*solve the hanoi tower problem with n discs on the first tower and k towers*)
  let initial_tower_content =List.rev (make_list n) and free_towers = (List.tl (make_list (k-1))) in
  let towers=Array.make k [] in
  towers.(0)<-initial_tower_content;
  hanoi_multi_move_number n 0 (k-1) free_towers towers
;;

let res=Array.make_matrix 4 25 0;;
for i=7 to 7 do
  for j=0 to 24 do
    print_string"hanoi_multi_towers_number ";
    print_int((15)*j+5);
    print_string" ";
    print_int(i);
    print_string" : ";
    let r=hanoi_multi_towers_number ((15)*j+5) (i) in
    print_int(r);
    res.(i-7).(j)<-r;
    print_newline();
  done;
  print_newline();
done;
res;;


#load "graphics.cma";;
Graphics.open_graph " 1024x768";;


let move_disc initial final towers = (*Move a disc from initial tower to final tower. towers is an array that represents the configration of the 3 towers : each case contains a list of the discs currently on this tower.*)
  print_string "The disc ";
  print_int (List.hd(towers.(initial)));
  towers.(final)<-((List.hd(towers.(initial)))::towers.(final)); (*The top disc of tower inital is taken and put ontop of tower final*)
  towers.(initial)<-(List.tl(towers.(initial))); (*The top disc of tower initial is deleted from tower initial*)
  print_string" is moved from tower ";
  print_int (initial+1); (* Tower number is shifted to start with 1 instead of 0*)
  print_string" to tower ";
  print_int (final+1);
  print_newline();
  ();;

let rec draw_tower x y scale = function (*Draws the discs currently on the tower from the list of these discs starts in x y and goes up by scale at each disc*)
  |[]->()
  |hd::tl ->Graphics.set_color (0xFF0000); Graphics.fill_rect (x+5-5*hd) y (10*hd) 5 ; (*Draws the disc hd itself : a rectangle of which size is proportional to it's number*)
    Graphics.set_color (0x000000); Graphics.set_text_size 14; Graphics.moveto (x-12) (y+7); Graphics.draw_string (string_of_int hd); (*Moves the cursor to the side on the rectange and draw the number of the disc*)
    draw_tower x (y +scale) scale tl (*Draws the rest of the tower, starting a bit ahead the former disc*)
;;


let draw_hanoi towers= (*draw the whole state of the three towers*) 
  Graphics.clear_graph();
  Graphics.set_color (0x000000);
  let n=Array.length towers in
  let space=(800/(n-1)) in (*définit l'espacement entre les tours*) 
  for i=0 to n-1 do
    Graphics.fill_rect (100+i*space) 0 10 600;(* draws the towers themselves : three rectangles*)
    draw_tower (100+i*space) 0  30 (List.rev towers.(i));
  done;
;;

let wait_until_key_pressed () = (*waits for the user to press a key before resuming the process. Clears the graph after the key is pressed*)
  let  a=Graphics.wait_next_event([Graphics.Key_pressed]) in
  Graphics.clear_graph();;

let rec hanoi_rec n initial final middle towers = (*solve the hanoi towers problem with n discs stacked on initial towers and puts these on final tower*)
  if n=0 then begin draw_hanoi towers; end
  else 
    begin
      hanoi_rec (n-1) initial middle final towers; (*puts the n-1 firsts discs on the middle tower*)

      draw_hanoi towers;(* draws th current state of the game*)
      wait_until_key_pressed (); (*wait the user to continue*)
      move_disc initial final towers; (*moves le last  and larger disc from th initial tower to the final tower*)
      hanoi_rec (n-1) middle final initial towers; (*moves les n-1 smaller discs from the middle tower to the final tower*)
    end;
;;

let rec make_list =function (*make a list of the n first integers in descending order*)
  |0->[]
  |n->n::make_list (n-1)
;;


let hanoi_towers n= (*solve the hanoi tower problem with n discs on the first tower*)
  let initial_tower_content =List.rev (make_list n) in
  hanoi_rec n 0 2 1 [|initial_tower_content;[];[]|]
;;

let rec hanoi_multi disc_number initial final free towers = 
  if disc_number=0 then (draw_hanoi towers; wait_until_key_pressed())
  else 
  let k=(List.length free) in
  if (disc_number<=k+1) then (*The discs are scattered on the free towers, one disc per tower.*)
    begin
      let first_free_list=ref [] and free_temp=ref free in
      for j=0 to (disc_number-2) do
	draw_hanoi towers;
	wait_until_key_pressed();	
	first_free_list:=(List.hd !free_temp)::(!first_free_list);
	free_temp:=(List.tl !free_temp);
	move_disc initial (List.hd !first_free_list) towers;
      done;
      draw_hanoi towers;
      wait_until_key_pressed();	
      move_disc initial final towers;
      for j=0 to disc_number-2 do (* the scattered discs are moved toward the final tower in the right order*)
	draw_hanoi towers;
	wait_until_key_pressed();
	move_disc (List.hd !first_free_list) final towers;
	first_free_list :=(List.tl !first_free_list);
      done;
    end
  else
    if k=1 then (hanoi_rec disc_number initial final (List.hd free) towers)
    else
      let first_free=(List.hd free) in
      draw_hanoi towers;
       wait_until_key_pressed (); (*wait the user to continue*)
      (hanoi_multi (disc_number/2) initial first_free (List.tl free) towers; (*puts the n/2 firsts discs on the first free tower*)
       hanoi_multi (disc_number-disc_number/2) initial final (List.tl free) towers; (*moves the remnants discs from the initial tower to the final tower*) 
       hanoi_multi (disc_number/2) first_free final (initial::List.tl free) towers;) (*moves the remnants discs from the last first_free tower to the final tower*)
;;

let hanoi_multi_towers n k= (*solve the hanoi tower problem with n discs on the first tower and k towers*)
  let initial_tower_content =List.rev (make_list n) and free_towers = (List.tl (make_list (k-1))) in
  let towers=Array.make k [] in
  towers.(0)<-initial_tower_content;
  hanoi_multi n 0 (k-1) free_towers towers
;;

let rec hanoi_rec_move_number n initial final middle towers = (*solve the hanoi towers problem with n discs stacked on initial towers and puts these on final tower*)
  if n=0 then 0
  else 
    begin
      let res=hanoi_rec_move_number (n-1) initial middle final towers in (*puts the n-1 firsts discs on the middle tower*)
      move_disc initial final towers; (*moves le last  and larger disc from th initial tower to the final tower*)
      res+1+hanoi_rec_move_number (n-1) middle final initial towers; (*moves les n-1 smaller discs from the middle tower to the final tower*)
    end;
;;

let rec hanoi_multi_move_number disc_number initial final free towers = 
  if disc_number=0 then 0
  else 
    let k=(List.length free) in
    if disc_number<=(k+1) then (*The discs are scattered on the free towers, one disc per tower.*)
      begin
	  let first_free_list=ref [] and free_temp=ref free in
	  for j=0 to (disc_number-2) do
	    first_free_list:=(List.hd !free_temp)::(!first_free_list);
	    free_temp:=(List.tl !free_temp);
	    move_disc initial (List.hd !first_free_list) towers;
	  done;
	  move_disc initial final towers;
	  for j=0 to disc_number-2 do (* the scattered discs are moved toward the final tower in the right order*)
	    move_disc (List.hd !first_free_list) final towers;
	    first_free_list :=(List.tl !first_free_list);
	  done;
	  2*disc_number-1;
      end
      else
      if k=1 then (hanoi_rec_move_number disc_number initial final (List.hd free) towers)
      else
	
	let first_free=(List.hd free) and res=ref 0 in
	res := !res+(hanoi_multi_move_number (disc_number/2) initial first_free (List.tl free) towers); (*puts the n/2 firsts discs on the first free tower*)
	res:=!res+(hanoi_multi_move_number (disc_number-disc_number/2) initial final (List.tl free) towers); (*moves the remnants discs from the initial tower to the final tower*) 
	res:=!res+(hanoi_multi_move_number (disc_number/2) first_free final (initial::List.tl free) towers); (*moves the remnants discs from the last first_free tower to the final tower*)
	    !res;
;;

let hanoi_multi_towers_number n k= (*solve the hanoi tower problem with n discs on the first tower and k towers*)
  let initial_tower_content =List.rev (make_list n) and free_towers = (List.tl (make_list (k-1))) in
  let towers=Array.make k [] in
  towers.(0)<-initial_tower_content;
  hanoi_multi_move_number n 0 (k-1) free_towers towers
;;

print_string "Classical Hanoi, 5 discs. Press any key to continue";;
wait_until_key_pressed();;

hanoi_towers 5;;
Graphics.close_graph;;
print_string"Classical Hanoi, n discs. Enter n to continue";;
print_newline();;
wait_until_key_pressed();;
let n=read_int();;
hanoi_towers n;;
print_string"Hanoi with k>3 towers, n discs. Enter n to continue";;
print_newline();;
let n=read_int();;
print_string"Please enter k to continue";;
print_newline();;
let k=read_int();;
hanoi_multi_towers n k;;
print_string"Press any key to finish";;
wait_until_key_pressed();;
Graphics.close_graph();;


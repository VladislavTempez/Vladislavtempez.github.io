let move_disc initial final towers = (*Move a disc from initial tower to final tower. towers is an array that represents the configration of the 3 towers : each case contains a list of the discs currently on this tower.*)
  print_string "The disc ";
  print_int (List.hd(towers.(initial)));
  towers.(final)<-((List.hd(towers.(initial)))::towers.(final)); (*The top disc of tower inital is taken and put ontop of tower final*)
  towers.(initial)<-(List.tl(towers.(initial))); (*The top disc of tower initial is deleted from tower initial*)
  print_string" is moved from tower ";
  print_int (initial+1); (* Tower number is shifted to start with 1 instead of 0*)
  print_string" to tower ";
  print_int (final+1);
  print_string ".";
  print_newline();
();;

let rec hanoi_rec n initial final middle towers = (*solve the hanoi towers problem with n discs stacked on initial towers and puts these on final tower*)
  if n=0 then ()
     else 
   begin
     hanoi_rec (n-1) initial middle final towers; (*puts the n-1 firsts discs on the middle tower*)
     move_disc initial final towers; (*moves le last  and larger disc from th initial tower to the final tower*)
     hanoi_rec (n-1) middle final initial towers; (*moves les n-1 smaller discs from the middle tower to the final tower*)
   end;
;;

let rec make_list =function (*make a list of the n first integers in descending order*)
  |0->[]
  |n->n::make_list (n-1)
;;


let hanoi_towers n= (*solve the hanoi tower problem with n discs on the first tower*)
  let initial_tower_content =List.rev (make_list n) in
  hanoi_rec n 0 2 1 [|initial_tower_content;[];[]|];;
hanoi_towers 5;;
